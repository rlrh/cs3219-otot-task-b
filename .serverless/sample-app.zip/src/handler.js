(function(e, a) { for(var i in a) e[i] = a[i]; }(exports, /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 6);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("express");

/***/ }),
/* 1 */
/***/ (function(module, exports) {

module.exports = require("mongoose");

/***/ }),
/* 2 */
/***/ (function(module, exports) {

module.exports = require("serverless-http");

/***/ }),
/* 3 */
/***/ (function(module, exports) {

module.exports = require("cors");

/***/ }),
/* 4 */
/***/ (function(module, exports) {

module.exports = require("dotenv/config");

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("uuid");

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXTERNAL MODULE: external "serverless-http"
var external_serverless_http_ = __webpack_require__(2);
var external_serverless_http_default = /*#__PURE__*/__webpack_require__.n(external_serverless_http_);

// EXTERNAL MODULE: external "express"
var external_express_ = __webpack_require__(0);
var external_express_default = /*#__PURE__*/__webpack_require__.n(external_express_);

// EXTERNAL MODULE: external "cors"
var external_cors_ = __webpack_require__(3);
var external_cors_default = /*#__PURE__*/__webpack_require__.n(external_cors_);

// EXTERNAL MODULE: external "dotenv/config"
var config_ = __webpack_require__(4);

// EXTERNAL MODULE: external "mongoose"
var external_mongoose_ = __webpack_require__(1);
var external_mongoose_default = /*#__PURE__*/__webpack_require__.n(external_mongoose_);

// CONCATENATED MODULE: ./src/models/user.js

const userSchema = new external_mongoose_default.a.Schema({
  username: {
    type: String,
    unique: true,
    required: true
  }
}, {
  timestamps: true
});

userSchema.statics.findByLogin = async function (login) {
  let user = await this.findOne({
    username: login
  });

  if (!user) {
    user = await this.findOne({
      email: login
    });
  }

  return user;
};

userSchema.pre('remove', function (next) {
  this.model('Message').deleteMany({
    user: this._id
  }, next);
});
const User = external_mongoose_default.a.model('User', userSchema);
/* harmony default export */ var user = (User);
// CONCATENATED MODULE: ./src/models/message.js

const messageSchema = new external_mongoose_default.a.Schema({
  text: {
    type: String,
    required: true
  },
  user: {
    type: external_mongoose_default.a.Schema.Types.ObjectId,
    ref: 'User'
  }
}, {
  timestamps: true
});
const Message = external_mongoose_default.a.model('Message', messageSchema);
/* harmony default export */ var message = (Message);
// CONCATENATED MODULE: ./src/models/index.js




const connectDb = databaseUrl => {
  return external_mongoose_default.a.connect(databaseUrl);
};

const disconnectDb = () => {
  return external_mongoose_default.a.connection.close();
};

const models = {
  User: user,
  Message: message
};

/* harmony default export */ var src_models = (models);
// CONCATENATED MODULE: ./src/routes/session.js

const router = Object(external_express_["Router"])();
router.get('/', async (req, res) => {
  const user = await req.context.models.User.findById(req.context.me.id);
  return res.send(user);
});
/* harmony default export */ var session = (router);
// CONCATENATED MODULE: ./src/routes/user.js

const user_router = Object(external_express_["Router"])();
user_router.get('/', async (req, res) => {
  const users = await req.context.models.User.find();
  return res.send(users);
});
user_router.get('/:userId', async (req, res) => {
  const user = await req.context.models.User.findById(req.params.userId);
  return res.send(user);
});
/* harmony default export */ var routes_user = (user_router);
// EXTERNAL MODULE: external "uuid"
var external_uuid_ = __webpack_require__(5);

// CONCATENATED MODULE: ./src/routes/message.js


const message_router = Object(external_express_["Router"])();
message_router.get("/", async (req, res) => {
  const messages = await req.context.models.Message.find();
  return res.send(messages);
});
message_router.get("/:messageId", async (req, res, next) => {
  const message = await req.context.models.Message.findById(req.params.messageId).catch(error => {
    error.statusCode = 400;
    next(error);
  });
  return res.send(message);
});
message_router.post("/", async (req, res, next) => {
  const message = await req.context.models.Message.create({
    text: req.body.text,
    user: req.context.me.id
  }).catch(error => {
    error.statusCode = 400;
    next(error);
  });
  return res.send(message);
});
message_router.put("/:messageId", async (req, res, next) => {
  try {
    const message = await req.context.models.Message.findById(req.params.messageId);

    if (message.user != req.context.me.id) {
      throw new Error("User is not creator of message");
    } else {
      message.text = req.body.text;
      await message.save();
      return res.send(message);
    }
  } catch (error) {
    error.statusCode = 400;
    next(error);
  }
});
message_router.delete("/:messageId", async (req, res, next) => {
  try {
    const message = await req.context.models.Message.findById(req.params.messageId);

    if (message.user != req.context.me.id) {
      throw new Error("User is not creator of message");
    }

    if (message) {
      await message.remove();
    }

    return res.send(message);
  } catch (error) {
    error.statusCode = 400;
    next(error);
  }
});
/* harmony default export */ var routes_message = (message_router);
// CONCATENATED MODULE: ./src/routes/index.js



/* harmony default export */ var routes = ({
  session: session,
  user: routes_user,
  message: routes_message
});
// CONCATENATED MODULE: ./src/app.js





const app = external_express_default()();
app.use(external_cors_default()());
app.use(external_express_default.a.json());
app.use(external_express_default.a.urlencoded({
  extended: true
}));
app.use(async (req, res, next) => {
  req.context = {
    models: src_models,
    me: await src_models.User.findByLogin('rayner.lim')
  };
  next();
});
app.use('/session', routes.session);
app.use('/users', routes.user);
app.use('/messages', routes.message);
app.get('*', function (req, res, next) {
  const error = new Error(`${req.ip} tried to access ${req.originalUrl}`);
  error.statusCode = 301;
  next(error);
});
app.use((error, req, res, next) => {
  if (!error.statusCode) error.statusCode = 500;

  if (error.statusCode === 301) {
    return res.status(301).redirect('/not-found');
  }

  return res.status(error.statusCode).json({
    error: error.toString()
  });
});

if (true) {
  const eraseDatabaseOnSync = true;
  connectDb(process.env.PROD_DATABASE_URL).then(async () => {
    if (eraseDatabaseOnSync) {
      await Promise.all([src_models.User.deleteMany({}), src_models.Message.deleteMany({})]);
      createUsersWithMessages();
    }
  });

  const createUsersWithMessages = async () => {
    const user1 = new src_models.User({
      username: 'rayner.lim'
    });
    const user2 = new src_models.User({
      username: 'mil.renyar'
    });
    const message1 = new src_models.Message({
      text: 'Learnt Express.js',
      user: user1.id
    });
    const message2 = new src_models.Message({
      text: 'Experimented with Mongoose',
      user: user1.id
    });
    const message3 = new src_models.Message({
      text: 'React or Vue for the frontend?',
      user: user2.id
    });
    await message1.save();
    await message2.save();
    await message3.save();
    await user1.save();
    await user2.save();
  };
}

;
/* harmony default export */ var src_app = (app);
// CONCATENATED MODULE: ./src/handler.js


/* harmony default export */ var handler = __webpack_exports__["default"] = (external_serverless_http_default()(src_app));

/***/ })
/******/ ])));
//# sourceMappingURL=handler.js.map